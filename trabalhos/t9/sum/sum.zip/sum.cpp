#include <stdio.h>
#include <sstream>
#include <mpi.h>

void sum(char* output, const long unsigned int d, const long unsigned int n) {
    long unsigned int digits[d + 11], digitss[d + 11];
    for (long unsigned int digit = 0; digit < d + 11; ++digit) {
        digits[digit] = 0;
    }

    int pid, psize;
    MPI_Comm_rank(MPI_COMM_WORLD, &pid);
    MPI_Comm_size(MPI_COMM_WORLD, &psize);

    for (long unsigned int i = 1+pid; i <= n; i+=psize) {
        long unsigned int remainder = 1;
        for (long unsigned int digit = 0; digit < d + 11 && remainder; ++digit) {
            digits[digit] += remainder / i;
            remainder = (remainder % i) * 10;
        }
    }

    MPI_Reduce(&digits, &digitss, d+11, MPI_UNSIGNED_LONG, MPI_SUM, 0, MPI_COMM_WORLD);

    if (pid == 0) {
        for (long unsigned int i = d + 11 - 1; i > 0; --i) {
            digitss[i - 1] += digitss[i] / 10;
            digitss[i] %= 10;
        }
	    if (digitss[d + 1] >= 5) {
            ++digitss[d];
        }
	    for (long unsigned int i = d; i > 0; --i) {
            digitss[i - 1] += digitss[i] / 10;
            digitss[i] %= 10;
        }

	    int i = 0;
        if (digitss[0]/1000 > 0) {
            output[i] = (digitss[0]/1000) + '0';
            digitss[0] %= 1000;
            i++;
        }
	    if (digitss[0]/100 > 0) {
            output[i] = (digitss[0]/100) + '0';
            digitss[0] %= 100;
            i++;
        }
	    if (digitss[0]/10 > 0) {
            output[i] = (digitss[0]/10) + '0';
            digitss[0] %= 10;
            i++;
        }
	    output[i] = digitss[0] + '0';
        i++;

	    output[i] = '.';
        i++;
	    int j;
	    for (j = 1; j <= d; j++) {
            output[i] = digitss[j] + '0';
            i++;
        }
	    output[i] = '\0';
    }
}

int main(int argc, char** argv) {

    MPI_Status stat;
    MPI_Init(&argc, &argv);

    int pid;
    MPI_Comm_rank(MPI_COMM_WORLD, &pid);

    long unsigned int d, n;

    scanf("%lu", &d);
    scanf("%lu", &n);

    char output[d + 10]; // extra precision due to possible error

    sum(output, d, n);

    if (pid == 0)
        printf("%s\n", output);

    MPI_Finalize();

    return 0;
}
